import { Component } from '@angular/core';
import axios from 'axios';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
})
export class Tab2Page {
  public inputMessage: string = '';

  public messages: string[] = [];
  public messages2: string[] = [];
  public messages3: string[] = [];
  public messages4: string[] = [];
  public messages5: string[] = [];
  public messages6: string[] = [];
  public messages7: string[] = [];

  public allData: any = [];
  public allData2: any = [];
  public allData3: any = [];
  public allData4: any = [];
  public allData6: any = [];

  showSecondElement1: boolean = false;
  showPopUp: boolean = false;

  handleRefresh(event: any) {
    setTimeout(() => {
      event.target.complete();
    }, 2000);
  }

  constructor() {
    this.create();
  }

  async create() {
    const res: any = await axios.get('https://praktikum-cpanel-unbin.com/Ap_Opang/get_data1.php');
    const res2: any = await axios.get('https://praktikum-cpanel-unbin.com/Ap_Opang/get_data2.php');
    const res3: any = await axios.get('https://praktikum-cpanel-unbin.com/Ap_Opang/get_data3.php');
    const res4: any = await axios.get('https://praktikum-cpanel-unbin.com/Ap_Opang/get_data4.php');
    const res5: any = await axios.get('https://praktikum-cpanel-unbin.com/Ap_Opang/get_data5.php');

    if (this.inputMessage == 'Senin' || this.inputMessage == 'senin') {
      console.log(res.data);
      this.allData = res.data.result;
      this.messages.push(this.inputMessage);
      this.showSecondElement1 = true;
      this.inputMessage = '';
    }
    if (this.inputMessage == 'Selasa'|| this.inputMessage== 'selasa') {
      this.messages2.push(this.inputMessage);
      this.showPopUp = true;
      this.inputMessage = '';
    }
    if (this.inputMessage === 'Rabu' || this.inputMessage == 'rabu') {
      console.log(res3.data);
      this.allData3 = res3.data.result;
      this.messages3.push(this.inputMessage);
      this.showSecondElement1 = true;
      this.inputMessage = '';
    }
    if (this.inputMessage === 'Kamis' || this.inputMessage == 'kamis') {
      console.log(res4.data);
      this.allData4 = res4.data.result;
      this.messages4.push(this.inputMessage);
      this.showSecondElement1 = true;
      this.inputMessage = '';
    }
    if (this.inputMessage === 'Jumat' || this.inputMessage == 'jumat') {
      console.log(res2.data);
      this.allData2 =res2.data.result;
      this.messages5.push(this.inputMessage);
      this.showSecondElement1 = true;
      this.inputMessage = '';
    }

    if (this.inputMessage === 'Sabtu' || this. inputMessage == 'sabtu') {
      console.log(res5.data);
      this.allData6 = res5.data.result;
      this.messages6.push(this.inputMessage);
      this.showSecondElement1 = true;
      this.inputMessage = '';
    }
    if (this.inputMessage) {
      this.messages7.push(this.inputMessage);
    }
  }

  sendMessage() {
    this.create();
  }
}
