<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Origin, Content-Type, Authorization, Accept, X-Requested-With, x-xsrf-token");
header("Content-Type: application/json; charset=utf-8");

include "config.php";
$data = array();

// Check if npm parameter is set in the request
if(isset($_GET['npm'])) {
    // Sanitize and get the npm value
    $npm = mysqli_real_escape_string($kon, $_GET['npm']);

    // Use the npm value in the SQL query
    $query = mysqli_query($kon, "SELECT * FROM nilai WHERE npm = '$npm'");
    
    while($rows = mysqli_fetch_array($query)){
        $data[] = array(
            'kd_mk' => $rows['kd_nilai'],
            'npm'=> $rows['npm'],
            'mtkuliah'=> $rows['matkul'],
            'dosen'=> $rows['dosen'],
            'point' => $rows['point'],
            'grade'=> $rows['grade']
        );
    }

    if($query){
        $result = json_encode(array('success'=>true, 'result'=>$data));
    } else {
        $result = json_encode(array('success'=>false));
    }
} else {
    // Handle case when npm parameter is not set
    $result = json_encode(array('success'=>false, 'message'=>'npm parameter is missing'));
}

echo $result;
?>
