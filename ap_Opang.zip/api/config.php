<?php
    define('DB_NAME', 'praktikum_mobile_platform');
    define('DB_USER', 'pratikum');
    define('DB_PASSWORD', 'RomOf]#WJY5w');
    define('DB_HOST', 'https://praktikum-cpanel-unbin.com/');

    $kon = mysqli_connect("https://praktikum-cpanel-unbin.com/", "pratikum", "RomOf]#WJY5w", "praktikum_mobile_platform") or die(mysqli_error());
?>
